
Somya Traders & Suppliers — Ready-to-run React site (Vite)

What's included:
- Simple React app (Vite) with:
  - Live Saria prices via Google Sheet (you must publish the sheet)
  - Contact form with WhatsApp + Email options
  - Feedback form (WhatsApp + Email)
  - Theme toggle, zoom controls, member demo toggle
  - Updated contact & address

How to run locally (Windows — minimal steps):
1) Unzip the project (if zipped). Open PowerShell in the project folder.
2) Install Node.js (if not installed): https://nodejs.org/
3) Run:
   npm install
   npm run dev
4) Open http://localhost:5173 in your browser (Vite default)

Set up Google Sheet for live prices:
1) Create a Google Sheet with columns: City | Grade | PriceINRperTonne
2) File → Share → Publish to web (choose the sheet tab)
3) Copy the Sheet ID from the URL:
   https://docs.google.com/spreadsheets/d/<THIS_IS_THE_ID>/edit...
4) Open src/config.js and replace YOUR_GOOGLE_SHEET_ID with that ID.
5) Save and refresh the site.

Deploy options (choose one):
A) Vercel (recommended, easiest)
   - Create a GitHub repository and push this project (or use Vercel 'Import Project' and connect GitHub).
   - Vercel will detect Vite/React automatically. Set the environment variable if needed.
   - Deploy.

B) Netlify (drag & drop)
   - Run `npm run build`
   - Upload the generated `dist/` folder from the project root in Netlify's Drag & Drop deploy.

C) GitHub Pages
   - Not ideal for Vite without extra setup. Prefer Vercel/Netlify.

Notes:
- WhatsApp links use your number from src/config.js (international format without +, e.g., 918957117635).
- Email uses the address in src/config.js.
- If you want, I can push this project to a GitHub repo for you (you'll need to give me a repo name) or create a zipped download here.
