// Configure your Google Sheet ID here.
// Create a Google Sheet with columns: City | Grade | PriceINRperTonne
// File -> Share -> Publish to web
export const SETTINGS = {
  googleSheetId: "YOUR_GOOGLE_SHEET_ID",
  googleSheetRange: "Prices!A1:C200",
  refreshMs: 60000,
  contactPhone: "918957117635", // include country code without plus
  contactEmail: "Arishabh776@gmail.com"
}
