
import React, { useEffect, useMemo, useState } from "react";
import { SETTINGS } from "./config";

function fetchGoogleSheetINRPerTonne(googleSheetId, range) {
  if (!googleSheetId || googleSheetId.includes("YOUR_")) return Promise.resolve(null);
  const url = `https://docs.google.com/spreadsheets/d/${googleSheetId}/gviz/tq?tqx=out:json&range=${encodeURIComponent(range)}`;
  return fetch(url)
    .then(res => res.text())
    .then(text => {
      const json = JSON.parse(text.substring(text.indexOf("{"), text.lastIndexOf("}") + 1));
      const rows = json.table.rows || [];
      return rows.map(r => ({
        city: r.c?.[0]?.v || "",
        grade: r.c?.[1]?.v || "",
        price: Number(r.c?.[2]?.v || 0)
      })).filter(x => x.city && x.price);
    })
    .catch(err => {
      console.error(err);
      return null;
    });
}

export default function App(){
  const [prices, setPrices] = useState(null);
  const [form, setForm] = useState({name:"", phone:"", city:"", product:"", message:""});
  const [feedback, setFeedback] = useState("");
  const [dark, setDark] = useState(false);
  const [zoom, setZoom] = useState(100);
  const [isMember, setIsMember] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function load(){ 
      const rows = await fetchGoogleSheetINRPerTonne(SETTINGS.googleSheetId, SETTINGS.googleSheetRange);
      if(mounted) setPrices(rows);
    }
    load();
    const id = setInterval(load, SETTINGS.refreshMs);
    return ()=>{ mounted=false; clearInterval(id); }
  }, []);

  const cementTypes = [
    {name:"OPC (Ordinary Portland Cement)", available:true},
    {name:"PPC (Portland Pozzolana Cement)", available:true},
    {name:"PSC (Portland Slag Cement)", available:false},
    {name:"White Cement", available:true},
    {name:"Rapid Hardening Cement", available:true},
  ];

  function openWhatsAppWith(text){
    const base = `https://wa.me/${SETTINGS.contactPhone}?text=${encodeURIComponent(text)}`;
    window.open(base, "_blank");
  }
  function openMailTo(subject, body){
    window.location.href = `mailto:${SETTINGS.contactEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  }

  function handleInquirySend(mode){
    const body = `Inquiry:
Name: ${form.name}
Phone: ${form.phone}
City: ${form.city}
Product: ${form.product}
Message: ${form.message}`;
    if(mode === "whatsapp" || mode === "both") openWhatsAppWith(body);
    if(mode === "email" || mode === "both") openMailTo("New Inquiry", body);
    setForm({name:"", phone:"", city:"", product:"", message:""});
    alert("Done — opened contact options. Please complete sending in WhatsApp or your mail client.");
  }

  function handleFeedbackSend(mode){
    const body = `Website feedback:
${feedback}`;
    if(mode === "whatsapp" || mode === "both") openWhatsAppWith(body);
    if(mode === "email" || mode === "both") openMailTo("Website Feedback", body);
    setFeedback("");
    alert("Done — opened contact options. Please complete sending in WhatsApp or your mail client.");
  }

  function setProductInForm(product){
    setForm(f => ({...f, product}));
    window.location.href = "#contact";
  }

  return (
    <div className={dark ? "app dark" : "app"} style={{zoom: `${zoom}%`}}>
      <header className="header">
        <h1>Somya Traders and Suppliers</h1>
        <nav>
          <a href="#prices">Live Saria Price</a>
          <a href="#cement">Cement Types</a>
          <a href="#contact">Contact</a>
          <a href="#settings">Settings</a>
        </nav>
      </header>

      <main className="container">
        <section className="hero">
          <h2>All Types of Cement & TMT Saria — Genuine Rates • Fast Delivery</h2>
          <p>Wholesale & retail • Pan-India delivery • GST billing available</p>
        </section>

        <section id="prices" className="card">
          <h3>Live Saria Price (India)</h3>
          {prices === null ? <p>Set your Google Sheet ID in <code>src/config.js</code> and publish the sheet to web.</p> : prices.length === 0 ? <p>No rows in sheet.</p> : (
            <div className="price-grid">
              {prices.map((r,i)=>(
                <div key={i} className="price-row">
                  <div>{r.city} — {r.grade}</div>
                  <div>₹{r.price.toLocaleString()} / tonne</div>
                </div>
              ))}
            </div>
          )}
          <p className="muted">* Indicative. Local brand/size/grade and city freight may vary.</p>
        </section>

        <section id="cement" className="card">
          <h3>Cement Types & Availability</h3>
          <div className="grid-3">
            {cementTypes.map((c, idx)=>(
              <div key={idx} className="product-card">
                <div className="product-head">
                  <strong>{c.name}</strong>
                  <span className={c.available ? "badge available":"badge out"}>{c.available ? "Available":"Out of stock"}</span>
                </div>
                <p className="muted">Description for {c.name}.</p>
                <div className="product-actions">
                  <button disabled={!c.available} onClick={()=>setProductInForm(c.name)}>{c.available ? "Buy / Enquire":"Notify Me"}</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="card">
          <h3>Contact & Inquiry</h3>
          <form onSubmit={(e)=>{ e.preventDefault(); handleInquirySend("both"); }}>
            <div className="form-grid">
              <input placeholder="Your Name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} required />
              <input placeholder="Phone Number" value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} required />
              <input placeholder="City" value={form.city} onChange={e=>setForm({...form, city:e.target.value})} />
              <input placeholder="Product (e.g., OPC 50kg, 12mm TMT)" value={form.product} onChange={e=>setForm({...form, product:e.target.value})} />
              <textarea placeholder="Any details (quantity, brand preference, delivery date)" value={form.message} onChange={e=>setForm({...form, message:e.target.value})} />
            </div>

            <div className="form-actions">
              <button type="button" onClick={()=>handleInquirySend("whatsapp")}>Send via WhatsApp</button>
              <button type="button" onClick={()=>handleInquirySend("email")}>Send via Email</button>
              <button type="submit">Send Both</button>
            </div>
          </form>

          <div className="contact-info">
            <div>
              <strong>Showroom</strong>
              <div>Panwari (Mahoba), Pathakpura Road, UP</div>
            </div>
            <div>
              <strong>Call</strong>
              <div>+91-8957117635</div>
              <strong>Email</strong>
              <div>{SETTINGS.contactEmail}</div>
            </div>
            <div>
              <strong>Hours</strong>
              <div>Mon–Sat: 9:30 AM – 7:00 PM</div>
            </div>
          </div>
        </section>

        <section id="settings" className="card">
          <h3>Settings</h3>
          <div className="settings-row">
            <button onClick={()=>setDark(d=>!d)}>{dark ? "Light" : "Dark"} Theme</button>
            <button onClick={()=>setZoom(z=>Math.min(z+10,200))}>Zoom In</button>
            <button onClick={()=>setZoom(z=>Math.max(z-10,50))}>Zoom Out</button>
            <button onClick={()=>{
              if(isMember){ setIsMember(false); localStorage.removeItem('memberName'); alert('Logged out'); }
              else {
                const name = prompt('Member name to login (demo):');
                if(name){ setIsMember(true); localStorage.setItem('memberName', name); alert('Logged in as '+name); }
              }
            }}>{isMember ? "Logout" : "Login as Member"}</button>
          </div>
        </section>

        <section id="feedback" className="card">
          <h3>Feedback & Connect with Us</h3>
          <form onSubmit={(e)=>{ e.preventDefault(); handleFeedbackSend("both"); }}>
            <textarea placeholder="Your feedback here" value={feedback} onChange={e=>setFeedback(e.target.value)} required />
            <div className="form-actions">
              <button type="button" onClick={()=>handleFeedbackSend("whatsapp")}>WhatsApp</button>
              <button type="button" onClick={()=>handleFeedbackSend("email")}>Email</button>
              <button type="submit">Both</button>
            </div>
          </form>
        </section>

      </main>

      <footer className="footer">
        © {new Date().getFullYear()} Somya Traders and Suppliers — All rights reserved.
      </footer>
    </div>
  );
}
